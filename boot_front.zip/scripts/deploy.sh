#!/bin/bash

echo "📦 CodeDeploy 무중단 배포 시작"

APP_DIR="/opt/tomcat/tomcat-10/webapps/boot/jsp"
NEW_DIR="/home/ubuntu/new_front/jsp"

# 백업 (선택적)
BACKUP_DIR="/home/ubuntu/backup/jsp_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"
cp -r $APP_DIR/* "$BACKUP_DIR/"
echo "🔙 기존 JSP 백업 완료: $BACKUP_DIR"

# 새 파일 복사 (덮어쓰기)
cp -r $NEW_DIR/* $APP_DIR/
echo "🚀 JSP 무중단 덮어쓰기 완료"

# 권한 설정 (선택)
chown -R ubuntu:ubuntu $APP_DIR

echo "✅ 무중단 배포 완료"
